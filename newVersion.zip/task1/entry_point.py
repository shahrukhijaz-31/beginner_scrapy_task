from scrapy.cmdline import execute

execute(['scrapy', 'crawl', 'SheegoSpider', '-o', 'sheegoItemFile.json'])
# execute(['scrapy', 'crawl', 'quotes'])
# execute(['scrapy', 'shell', 'https://www.sheego.de/'])
